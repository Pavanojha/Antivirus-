"""
This is the object used to hold payload options for Ordnance to leverage
"""

class Payload_Details:

    def __init__(self):
        self.payload = ""
        self.lhost = ""
        self.lport = ""
        self.bad_chars = ""
