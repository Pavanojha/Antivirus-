Virus Total Notifier
=========

This is a fork of Mubix's original VT-notifier script (https://github.com/mubix/vt-notify).

Modifications from the original:

	-Gmail gem utilization added in (gem install gmail)
	-hash list can be hash:exename
	-t 0 defaults to a single run
