## Veil version


## OS Used - all info (architecture, linux flavor, etc)


## How did you install Veil? (Apt, Clone from Github, etc.)


## Did you run the setup script?


## Pastebin link to error you are encountering (include console actions you took prior to error)


## Expected behavior


## Any additional info you want to tell me